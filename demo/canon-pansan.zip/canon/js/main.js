(function() {
  var _h = document.documentElement.clientHeight;
  function PageUtil(selector) {
    this.ele = document.querySelectorAll(selector)[0];
    this.scaleNum = document.documentElement.clientWidth/640;
    _h = _h/this.scaleNum;
    var resps = document.querySelectorAll('.resp');
    for (var i = 0; i <= resps.length - 1; i++) {
      if (resps[i].offsetTop != 0) {
        resps[i].style.top = _h * (resps[i].offsetTop/1136) + 'px';
      }
    }
    return this;
  }
  PageUtil.prototype.response = function(height) {
    this.ele.style.cssText = "-webkit-transform-origin: 0 0 0px; -webkit-transform: scale(" +
        this.scaleNum + ");position: absolute; width: 640px; height:" + parseInt(height + 1) + "px";
    return this;
  };
  new PageUtil('.main').response(_h);
})();

(function() {
  var swiper = new Swiper('.swiper-container', {
    pagination: false,
    speed: 500,
    paginationClickable: true,
    direction: 'vertical',
    onInit: function(swiper) {
      swiperAnimateCache(swiper);
      swiperAnimate(swiper);
      // playMp3("http://mfiles.sohu.com/news/yf/enenh5/mp3/bgm2.mp3", 1);
    },
    onSlideChangeEnd: function(swiper) {
      swiperAnimate(swiper);
    },
    onSlideChangeStart: function(swiper) {
    }
  });

  var swiper2 = new Swiper('.swiper-container2', {
    pagination: false,
    speed: 500,
    slidesPerView: 'auto',
    freeMode: true,
    direction: 'vertical',
    slideClass: 'swiper-slide2',
    onInit: function(swipe) {
    },
    onSlideChangeEnd: function(swiper) {
    }
  });

  // scrolling
  var HTMLS = [
    '<div class="swiper-slide2 swiper-no-swiping">' +
      '<div class="bg44 animated fadeInUp"></div>' +
      '<div class="bg45 animated fadeInUp"></div>' +
      '<div class="bb44 animated zoomIn"></div>' +
    '</div>',

    '<div class="swiper-slide2 swiper-no-swiping">' +
      '<div class="bg43 animated zoomIn"></div>' +
      '<div class="bb42 animated zoomIn"></div>' +
      '<div class="bb43 animated zoomIn"></div>' +
    '</div>',

    '<div class="swiper-slide2 swiper-no-swiping">' +
      '<div class="bg41 animated fadeInLeft"></div>' +
      '<div class="bg42 animated fadeInRight"></div>' +
      '<div class="bb41 animated zoomIn"></div>' +
    '</div>',

    '<div class="swiper-slide2 swiper-no-swiping">' +
      '<div id="bg32" class="bg32 animated fadeInLeft"></div>' +
      '<div id="bg33" class="bg33 animated fadeInRight"></div>' +
      '<div id="bb32" class="bb32 animated zoomIn"></div>' +
      '<div class="bg34 animated fadeInUp"></div>' +
      '<div class="bb33 animated fadeInUp"></div>' +
    '</div>',

    '<div class="swiper-slide2 swiper-no-swiping">' +
      '<div class="bg31 animated fadeInUp"></div>' +
      '<div id="bb31" class="bb31 animated zoomIn"></div>' +
    '</div>'
  ];

  var startY, moveY;
  setTimeout(function() {
    $('#scrolling').on('touchstart', function(e) {
      startY = e.originalEvent.changedTouches[0].pageY;
    });
    $('#scrolling').on('touchend', function(e) {
      if (e.originalEvent.changedTouches[0].pageY - startY < 10) {
        // next
        if (HTMLS.length == 0) {
          swiper.slideTo(2, 500);
        } else {
          swiper2.appendSlide(HTMLS.pop()); // 加到Swiper的最后
          // if (HTMLS.length == 3) {
          //   ado.pause();
          //   playMp3('http://news.sohu.com/upload/yf/enenh5/mp3/kick.mp3', 1);
          // }
          // if (HTMLS.length == 2) {
          //   playMp3('http://news.sohu.com/upload/yf/enenh5/mp3/kick.mp3', 1);
          // }
          // if (HTMLS.length == 0) {
          //   playMp3('http://news.sohu.com/upload/yf/enenh5/mp3/kick.mp3', 1);
          // }
          swiper2.slideNext(500);
        }
      } else {
        if (HTMLS.length > 0) {
          swiper2.appendSlide(HTMLS.pop()); // 加到Swiper的最后
          // if (HTMLS.length == 3) {
          //   ado.pause();
          //   playMp3('http://news.sohu.com/upload/yf/enenh5/mp3/kick.mp3', 1);
          // }
          // if (HTMLS.length == 2) {
          //   playMp3('http://news.sohu.com/upload/yf/enenh5/mp3/kick.mp3', 1);
          // }
          // if (HTMLS.length == 0) {
          //   playMp3('http://news.sohu.com/upload/yf/enenh5/mp3/kick.mp3', 1);
          // }
          swiper2.slideNext(500);
        } else {
          swiper2.slidePrev(500);
        }
      }
    })
  }, 6000);
})();

$('#bg22').on('webkitAnimationEnd', function(e) {
  $('#bg22').css({
    'animation-duration': '1.2s',
    '-webkit-animation-duration': '1.2s',
    'animation-name': 'bg22',
    '-webkit-animation-name': 'bg22'
  })
});