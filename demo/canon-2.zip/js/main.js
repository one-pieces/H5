function playMp3(url, times) {
  var loop = times;
  var ado = document.createElement('AUDIO');
  ado.setAttribute('preload', '');
  ado.setAttribute('src', url);
  var findSource = setInterval(function() {
    if (!isNaN(ado.duration)) {
      ado.play();
      ado.addEventListener('ended', function() {
        
      })
    }
  });
  
  window.ado = ado;
}

function openModal(contentUrl, hideBtn, btnUrl) {
  $('<div class="modal-backdrop"></div>').appendTo($('body'));
  $('.modal').css({
    'display': 'block'
  }).on('touchend', function(e) {
    $('.modal').css({
      'display': 'none'
    });
    $('.modal-backdrop').css({
      'display': 'none'
    });
  });
  $('.cluePicture').css({
    'background': 'url('+ contentUrl +') no-repeat',
    'background-size': 'contain'
  });
  if (hideBtn) {
    $('.clueTip').hide();
  } else {
    var clueTipUrl = btnUrl || '../canon/images/findclues/btn_continue.png';
    $('.clueTip').css({
      'background': 'url('+ clueTipUrl +') no-repeat',
      'background-size': 'contain'
    });
  }
}

function changeStage(from, to) {
  $(from).css({
    'display': 'none'
  });
  $(to).css({
    'display': 'block'
  });
}

(function() {
  var _h = document.documentElement.clientHeight;
  function PageUtil(selector) {
    this.ele = document.querySelectorAll(selector)[0];
    this.scaleNum = document.documentElement.clientWidth/640;
    _h = _h/this.scaleNum;
    var resps = document.querySelectorAll('.resp');
    for (var i = 0; i <= resps.length - 1; i++) {
      if (resps[i].offsetTop != 0) {
        resps[i].style.top = _h * (resps[i].offsetTop/1136) + 'px';
      }
    }
    return this;
  }
  PageUtil.prototype.response = function(height) {
    this.ele.style.cssText = "-webkit-transform-origin: 0 0 0px; -webkit-transform: scale(" +
        this.scaleNum + ");position: absolute; width: 640px; height:" + parseInt(height + 1) + "px";
    return this;
  };
  new PageUtil('.main').response(_h);
})();

(function() {
  var swiper = new Swiper('.swiper-container', {
    pagination: false,
    speed: 500,
    paginationClickable: true,
    direction: 'vertical',
    onInit: function(swiper) {
      swiperAnimateCache(swiper);
      swiperAnimate(swiper);
      // playMp3("http://mfiles.sohu.com/news/yf/enenh5/mp3/bgm2.mp3", 1);
    },
    onSlideChangeEnd: function(swiper) {
      swiperAnimate(swiper);
    },
    onSlideChangeStart: function(swiper) {
    }
  });

  var swiper2 = new Swiper('.swiper-container2', {
    pagination: false,
    speed: 500,
    slidesPerView: 'auto',
    freeMode: true,
    direction: 'vertical',
    slideClass: 'swiper-slide2',
    onInit: function(swipe) {
    },
    onSlideChangeEnd: function(swiper) {
    }
  });

  // scrolling
  var HTMLS = [
    '<div class="swiper-slide2 swiper-no-swiping">' +
      '<div class="bg44 animated fadeInUp"></div>' +
      '<div class="bg45 animated fadeInUp"></div>' +
      '<div class="bb44 animated zoomIn"></div>' +
    '</div>',

    '<div class="swiper-slide2 swiper-no-swiping">' +
      '<div class="bg43 animated zoomIn"></div>' +
      '<div class="bb42 animated zoomIn"></div>' +
      '<div class="bb43 animated zoomIn"></div>' +
    '</div>',

    '<div class="swiper-slide2 swiper-no-swiping">' +
      '<div class="bg41 animated fadeInLeft"></div>' +
      '<div class="bg42 animated fadeInRight"></div>' +
      '<div class="bb41 animated zoomIn"></div>' +
    '</div>',

    '<div class="swiper-slide2 swiper-no-swiping">' +
      '<div id="bg32" class="bg32 animated fadeInLeft"></div>' +
      '<div id="bg33" class="bg33 animated fadeInRight"></div>' +
      '<div id="bb32" class="bb32 animated zoomIn"></div>' +
      '<div class="bg34 animated fadeInUp"></div>' +
      '<div class="bb33 animated fadeInUp"></div>' +
    '</div>',

    '<div class="swiper-slide2 swiper-no-swiping">' +
      '<div class="bg31 animated fadeInUp"></div>' +
      '<div id="bb31" class="bb31 animated zoomIn"></div>' +
    '</div>'
  ];

  var startY;
  setTimeout(function() {
    $('#scrolling').on('touchstart', function(e) {
      startY = e.originalEvent.changedTouches[0].pageY;
    });
    $('#scrolling').on('touchend', function(e) {
      if (e.originalEvent.changedTouches[0].pageY - startY < 10) {
        // next
        if (HTMLS.length == 0) {
          swiper.slideTo(2, 500);
        } else {
          swiper2.appendSlide(HTMLS.pop()); // 加到Swiper的最后
          // if (HTMLS.length == 3) {
          //   ado.pause();
          //   playMp3('http://news.sohu.com/upload/yf/enenh5/mp3/kick.mp3', 1);
          // }
          // if (HTMLS.length == 2) {
          //   playMp3('http://news.sohu.com/upload/yf/enenh5/mp3/kick.mp3', 1);
          // }
          // if (HTMLS.length == 0) {
          //   playMp3('http://news.sohu.com/upload/yf/enenh5/mp3/kick.mp3', 1);
          // }
          swiper2.slideNext(500);
        }
      } else {
        if (HTMLS.length > 0) {
          swiper2.appendSlide(HTMLS.pop()); // 加到Swiper的最后
          // if (HTMLS.length == 3) {
          //   ado.pause();
          //   playMp3('http://news.sohu.com/upload/yf/enenh5/mp3/kick.mp3', 1);
          // }
          // if (HTMLS.length == 2) {
          //   playMp3('http://news.sohu.com/upload/yf/enenh5/mp3/kick.mp3', 1);
          // }
          // if (HTMLS.length == 0) {
          //   playMp3('http://news.sohu.com/upload/yf/enenh5/mp3/kick.mp3', 1);
          // }
          swiper2.slideNext(500);
        } else {
          swiper2.slidePrev(500);
        }
      }
    })
  }, 6000);
  window.swiper = swiper;
})();

(function() {
  var swipAnimate = new Animate();
  swipAnimate.initSwipe();
})();

/* 线索查找场景 */
(function() {
  var gridIndex = 1;
  var rightClueId = ['arrow1', 'arrow2', 'arrow3'];
  $('#wrap .arrow').on('touchend', function(e) {
    var target = e.target;
    var clueGrids = {
      arrow1: '../canon/images/findclues/mark_fingerprint.png',
      arrow2: '../canon/images/findclues/mark_contract.png',
      arrow3: '../canon/images/findclues/mark_printer.png'
    };
    var cluePictures = {
      arrow1: '../canon/images/findclues/correct_fingerprint.png',
      arrow2: '../canon/images/findclues/correct_contract.png',
      arrow3: '../canon/images/findclues/correct_printer.png',
      arrow4: '../canon/images/findclues/wrong_computer.png',
      arrow5: '../canon/images/findclues/wrong_drawer.png',
      arrow6: '../canon/images/findclues/wrong_phone.png',
      finalclues: '../canon/images/findclues/finalclues.png'
    };
    openModal(cluePictures[target.id]);

    var index = rightClueId.indexOf(target.id);
    if (index > -1) {
      rightClueId.splice(index, 1);
      $('#grid' + gridIndex++).css({
        'background': 'url('+ clueGrids[target.id] +')'
      });
    }

    if (gridIndex > 3) {
      $('.modal').off('touchend');
      $('.clueTip').css({
        'display': 'none'
      });
      setTimeout(function() {
        $('.cluePicture').css({
          '-webkit-animation': 'fadeIn 1s',
          'animation': 'fadeIn 1s',
          'background': 'url(' + cluePictures.finalclues + ') no-repeat',
          'background-size': 'contain'
        });
        $('.clueTip').css({
          'display': 'block',
          '-webkit-animation': 'fadeIn 1s',
          'animation': 'fadeIn 1s',
          'background': 'url("../canon/images/findclues/btn_findclues.png") no-repeat',
          'background-size': 'contain'
        }).on('touchend', function(e) {
          $('.modal').css({
            'display': 'none'
          });
          $('.modal-backdrop').css({
            'display': 'none'
          });

          $('#wrap .arrow').hide();
          
          $('.findclues').css({
            'display': 'block'
          }).on('touchend', function() {
            changeStage('#findclues', '#finalclues');
          });
        });
      }, 1000);
    }
  });
})();

/* 最终线索场景 */
(function() {
  $('.bb52').on('webkitAnimationEnd', function(e) {
    $('#arrow7').css({
      'display': 'block'
    }).on('touchend', function() {
      changeStage('#finalclues', '#scancode');
    });
  });
})();

/* 二维码扫码场景 */
(function() {
  $('.bg534').on('webkitAnimationEnd', function() {
    $('#scancode .scrolltop').css({
      'display': 'block'
    });
    $('#noSwiping').removeClass('swiper-no-swiping');
  })
})();

/* 选择答案场景 */
(function() {
  $('#choice1').on('touchend', function() {
    openModal('../canon/images/truthchoice/answer_1.png', true);
  });
  $('#choice2').on('touchend', function() {
    openModal('../canon/images/truthchoice/answer_2.png', true);
  });
  $('#choice3').on('touchend', function() {
    changeStage('#truthchoice', '#truthrestore');
  });
})();